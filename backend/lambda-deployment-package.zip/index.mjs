// index.js

const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const fetch = require('node-fetch');
const crypto = require('crypto');

// Initialize the S3 client
const s3client = new S3Client({
  region: process.env.AWS_REGION || "us-east-1",
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

exports.handler = async (event) => {
  try {
    console.log(`Request received: ${JSON.stringify(event)}`);

    // Parse the event body
    const body = JSON.parse(event.body);
    const { url } = body.Data.URL;

    if (!url) {
      console.log('Missing URL in the request');
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing URL in the request' }),
      };
    }

    // Fetch the zip file from the URL
    console.log(`Fetching zip file from URL: ${url}`);

    const response = await fetch(url);

    if (!response.ok) {
      console.error('Error fetching the zip file:', response.statusText);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Could not fetch the zip file from the provided URL' }),
      };
    }

    const arrayBuffer = await response.arrayBuffer();
    const zipBuffer = Buffer.from(arrayBuffer);

    // Generate a unique key for the S3 object
    const timestamp = Date.now();
    const randomBytes = crypto.randomBytes(8).toString('hex');
    const s3Key = `packages/package_${timestamp}_${randomBytes}.zip`;

    // Upload the zip file to S3
    const bucketName = process.env.AWS_S3_BUCKET_NAME;

    if (!bucketName) {
      console.error('AWS_S3_BUCKET_NAME is not set in environment variables');
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Internal Server Error' }),
      };
    }

    const s3params = {
      Bucket: bucketName,
      Key: s3Key,
      Body: zipBuffer,
      ContentType: 'application/zip',
    };

    try {
      const s3Response = await s3client.send(new PutObjectCommand(s3params));
      console.log("Successfully uploaded to S3:", s3Response);
    } catch (error) {
      console.error("Error uploading to S3:", error);
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Error uploading to S3' }),
      };
    }

    // Respond with a success message
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Package uploaded successfully', s3Key: s3Key }),
    };

  } catch (error) {
    console.error('Error handling package upload:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal Server Error' }),
    };
  }
};
